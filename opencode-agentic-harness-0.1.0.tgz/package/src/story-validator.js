import { readFile } from "node:fs/promises"
import { isAbsolute, relative, resolve, sep } from "node:path"

const REQUIRED = {
  epic: [
    ["chapter purpose", /## Chapter purpose/i],
    ["start condition", /## Start condition/i],
    ["user-visible outcome", /## User-visible outcome/i],
    ["terminal demo", /## Terminal demo and acceptance/i],
    ["finite WU budget", /## Approved WU budget/i],
    ["WU sequence", /## Work Unit sequence/i],
    ["out-of-scope boundary", /## Out of scope/i],
  ],
  wu: [
    ["story connection", /## Story and Epic connection/i],
    ["one outcome", /## Single outcome/i],
    ["acceptance criteria", /## Acceptance criteria/i],
    ["scope boundary", /## Boundaries/i],
    ["dependencies", /## Dependencies/i],
    ["child WU prohibition", /CHILD_WORK_UNITS_ALLOWED:\s*NO/],
    ["stop condition", /## Stop condition/i],
  ],
}

export async function validateStoryFile(projectRoot, documentPath, documentType) {
  const root = resolve(projectRoot)
  if (isAbsolute(documentPath)) throw new Error("document_path must be relative to the project root.")
  const file = resolve(root, documentPath)
  const rel = relative(root, file)
  if (rel === ".." || rel.startsWith(`..${sep}`)) throw new Error("document_path escapes the project root.")
  if (!(documentType in REQUIRED)) throw new Error('document_type must be "epic" or "wu".')

  const content = await readFile(file, "utf8")
  const missing = REQUIRED[documentType].filter(([, pattern]) => !pattern.test(content)).map(([label]) => label)
  const invalid = []
  const warnings = []
  const activationBlockers = []
  const draftContract = hasDraftStatus(content)
  if (draftContract) activationBlockers.push("Contract is DRAFT / NON-EXECUTABLE; owner review, approval, and explicit activation are still required.")
  if (documentType === "epic") {
    const maxCountValue = readBudgetField(content, "Maximum WU count", invalid)
    const maxCount = maxCountValue?.match(/^(\d+)$/)
    const maximumWus = maxCount ? Number(maxCount[1]) : NaN
    if (!Number.isSafeInteger(maximumWus) || maximumWus < 1) {
      invalid.push("Maximum WU count must be a positive safe integer approved for this Epic.")
    }

    const approval = readBudgetField(content, "Approval reference", invalid)
    const approvalStatus = readBudgetField(content, "Budget approval status", invalid)
    if (!approvalStatus?.toUpperCase().startsWith("APPROVED")) {
      if (draftContract) activationBlockers.push("Epic WU count approval is pending; execution cannot be activated.")
      else invalid.push("Epic WU budget must have explicit APPROVED status before validation can pass.")
    }
    if (!isConcreteValue(approval) || hasPendingLanguage(approval)) {
      if (draftContract) activationBlockers.push("Epic WU budget needs a concrete owner approval reference before activation.")
      else invalid.push("Epic WU budget needs a concrete owner-approved decision reference.")
    }

    for (const field of ["Demo scenario", "Acceptance evidence", "End condition"]) {
      const value = content.match(new RegExp(`^\\s*-\\s*${field}:\\s*(.*?)\\s*$`, "im"))?.[1]
      if (!isConcreteValue(value)) invalid.push(`${field} must contain a concrete, non-placeholder value.`)
    }

    if (Number.isSafeInteger(maximumWus) && maximumWus >= 1) {
      const plannedWus = content.split(/\r?\n/).filter((line) => /^\|\s*\d+\s*\|\s*(?!\[WU ID\])[^|]+\|/i.test(line)).length
      if (plannedWus > maximumWus) invalid.push(`Work Unit sequence has ${plannedWus} entries, exceeding the approved maximum of ${maximumWus}.`)
    }
    if (/TBD|TODO|\[OWNER INPUT REQUIRED\]/i.test(content)) warnings.push("The Epic still contains unresolved placeholders outside the validated budget and terminal-outcome fields.")
  }
  if (documentType === "wu" && !/one coherent outcome|single outcome|indivisible outcome/i.test(content)) warnings.push("Confirm explicitly that the WU is indivisible and represents one coherent outcome.")
  if (documentType === "wu") {
    const activeTime = readBudgetField(content, "Active-time limit", invalid)
    const approval = readBudgetField(content, "Approval reference", invalid)
    if (!isFiniteDuration(activeTime)) {
      if (draftContract) activationBlockers.push("WU needs a finite positive owner-approved active-time limit before activation.")
      else invalid.push("WU needs a finite positive active-time limit, such as '90 minutes' or '2 hours'.")
    }
    if (!isConcreteValue(approval) || hasPendingLanguage(approval)) {
      if (draftContract) activationBlockers.push("WU execution budget needs a concrete owner approval reference before activation.")
      else invalid.push("WU execution budget needs a concrete owner-approved decision reference.")
    }
  }
  const recursiveLines = content.split(/\r?\n/).filter((line) =>
    /create (a )?(child|successor|follow-up) (work unit|wu)|spawn (a )?new wu/i.test(line)
      && !/\b(do not|don't|never|cannot|must not|prohibit|forbid)\b/i.test(line),
  )
  if (recursiveLines.length) warnings.push("Possible instruction to create recursive or automatic follow-up work; review this contract.")

  return {
    status: missing.length || invalid.length ? "FAIL" : warnings.length || activationBlockers.length ? "PASS_WITH_WARNINGS" : "PASS",
    document: documentPath,
    type: documentType,
    missing_required_sections: missing,
    invalid_fields: invalid,
    warnings,
    activation_ready: missing.length === 0 && invalid.length === 0 && activationBlockers.length === 0,
    activation_blockers: activationBlockers,
    note: "PASS measures contract structure and finite boundaries. It does not approve product scope or activate work; inspect activation_ready and activation_blockers separately.",
  }
}

function hasPendingLanguage(value) {
  return /\b(pending|not authorized|not approved|awaiting)\b/i.test(String(value ?? ""))
}

function hasDraftStatus(content) {
  const frontmatter = content.match(/^\uFEFF?---[ \t]*\r?\n[\s\S]*?\r?\n---[ \t]*(?:\r?\n|$)/)
  const metadata = frontmatter?.[0].match(/^\s*status:\s*(?:"([^"]*)"|'([^']*)'|([^#\s]+))\s*$/im)
  const metadataStatus = metadata?.[1] ?? metadata?.[2] ?? metadata?.[3] ?? ""
  const body = frontmatter ? content.slice(frontmatter[0].length) : content
  const bodyStatus = body.match(/^\s*Status:\s*(.*?)\s*$/im)?.[1] ?? ""
  return /\bDRAFT\b/i.test(metadataStatus) || /\bDRAFT\b/i.test(bodyStatus)
}

function isConcreteValue(value) {
  if (!value) return false
  const normalized = value.trim()
  return normalized.length > 0
    && !/^\[[^\]]*\]$/.test(normalized)
    && !/^(?:TBD|TODO|PENDING|text|none|n\/a|owner input required)$/i.test(normalized)
}

function isFiniteDuration(value) {
  if (!value) return false
  const match = value.trim().match(/^(\d+(?:\.\d+)?)\s*(seconds?|minutes?|hours?|days?|weeks?)$/i)
  if (!match) return false
  const amount = Number(match[1])
  return Number.isFinite(amount) && amount > 0
}

function readBudgetField(content, field, invalid) {
  const escapedField = field.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
  const matches = [...content.matchAll(new RegExp(`^\\s*-\\s*${escapedField}:\\s*(.*?)\\s*$`, "gim"))]
  if (matches.length > 1) {
    invalid.push(`${field} must appear exactly once; duplicate entries make the approved budget ambiguous.`)
  }
  return matches.length === 1 ? matches[0][1] : undefined
}
